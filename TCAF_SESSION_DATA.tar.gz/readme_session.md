#==============================================================
#                        REQUIRED CHANGES
#==============================================================
In order to load the .xcm files, one needs to change the "path-to-tcaf-table-model" accordingly, to their own local directory where the TCAF Table model is saved. Please do so first to avoid errors. 

After loading the xcm, the `fit' command needs to be run again.
#==============================================================
